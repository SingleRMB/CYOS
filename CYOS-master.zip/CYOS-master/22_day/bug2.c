void HariMain(void){
	for (;;) { }
}